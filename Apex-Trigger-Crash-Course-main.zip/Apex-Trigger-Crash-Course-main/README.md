## [Youtube Video Link For This Crash Course](https://youtu.be/xsi06y7NOLA?si=mDXSPn3iUULPdNFF)

## Follow me on X [@sfdcfacts](https://x.com/sfdcfacts)
